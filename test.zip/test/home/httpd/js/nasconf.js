<script>

function ClickNasService(obj)
{
        var prev_id = document.main_form.click_id.value;
        var prev_bgcolor=document.main_form.click_bg.value;
        var click_id = obj.id;

        if(prev_id == click_id) return;

        if(prev_id)
        {
                document.getElementById(prev_id).style.backgroundColor = prev_bgcolor;
                parent.document.getElementById(prev_id+"_table").style.display = "none";
        }

        parent.document.getElementById(click_id+"_table").style.display = "block";
        document.main_form.click_id.value = click_id;
        document.main_form.click_bg.value = obj.style.backgroundColor;
        SetCursor(obj);
        parent.document.nasmisc_fm.act.value = obj.id;
}

function ClickFTPPortMethod()
{
	var F = document.nasmisc_fm;

	if(!F.ftp_port_method)
		return;

	if(F.ftp_port_method.checked == false)
		ReadOnlyObj(F.ftp_port,0);
	else
	{
		F.ftp_port.value=21;
		ReadOnlyObj(F.ftp_port,1);
	}
}


function ClickServicePortMethod()
{
        var F = document.nasmisc_fm;

        if (!F.ipdisk_port_method)
		return;

        if (F.ipdisk_port_method.checked == false)
		ReadOnlyObj(F.ipdisk_port,0);
	else
	{
		F.ipdisk_port.value=9000;
		ReadOnlyObj(F.ipdisk_port,1);
	}

}

function ClickURLPortMethod()
{
        var F = document.nasmisc_fm;

	if(!F.url_port_method)
		return;
        if (F.url_port_method.checked == false)
	{
		ReadOnlyObj(F.url_port,0);
	}
	else
	{
		F.url_port.value=8000;
		ReadOnlyObj(F.url_port,1);
	}

}



function InitIPDISKService()
{
        var F = document.nasmisc_fm;


	if(F.url_port_method)
	{
		if(F.url_port.value == '8000') 
		{
                	F.url_port_method.checked = false;
			ReadOnlyObj(F.url_port,1);
		}
		else
		{
                	F.url_port_method.checked = true;
			ReadOnlyObj(F.url_port,0);
		}
	}

}



function check_login_id(s)
{
        for( i = 0 ; i < s.length; i++ )
        {
                if(((s.charAt(i) >= 'a') && (s.charAt(i) <= 'z')) ||
                        ((s.charAt(i) >= 'A' ) && (s.charAt(i) <= 'Z')) ||
                        ((s.charAt(i) >= '0' ) && (s.charAt(i) <= '9')) )
                                continue;
        	else
                        return false;
       }

       return true;
}


function check_unallowed_id(s)
{
	if( s == 'root')
		return false;
	if( s == 'nobody')
		return false;


       return true;
}



/*
function CheckUser(userid,passwdorg,passwd_text,passwd_view)
{
	var passwd;

        if(userid.value.length == 0 )
        {
                alert(MSG_BLANK_ACCOUNT);
                userid.focus();
                userid.select();
                return 1;
        }

	if(passwd_view.checked == true)
		passwd = passwd_text;
	else
		passwd = passwdorg;

        if( passwd.value.length == 0 )
        {
                alert(MSG_BLANK_PASSWORD);
                passwd.focus();
                passwd.select();
                return 1;
        }

	if (check_login_id(userid.value) == false)
	{
                alert(SYSCONF_LOGIN_INVALID_NEW_ID);
                userid.focus();
                userid.select();
                return 1;
	}

	if (check_unallowed_id(userid.value) == false)
	{
                alert(UNALLOWED_ID_MSG);
                userid.focus();
                userid.select();
                return 1;
	}

	return 0;
}
*/


function CheckUser(userid,passwdorg,passwd_text,passwd_view, property)
{
	var passwd;
	
	if(property && property.value == 'off')
		return 0;

        if(userid.value.length == 0 )
        {
                alert(MSG_BLANK_ACCOUNT);
                userid.focus();
                userid.select();
                return 1;
        }

	if(passwd_view.checked == true)
		passwd = passwd_text;
	else
		passwd = passwdorg;

        if( passwd.value.length == 0 )
        {
                alert(MSG_BLANK_PASSWORD);
                passwd.focus();
                passwd.select();
                return 1;
        }

	if (check_login_id(userid.value) == false)
	{
                alert(SYSCONF_LOGIN_INVALID_NEW_ID);
                userid.focus();
                userid.select();
                return 1;
	}

	if (check_unallowed_id(userid.value) == false)
	{
                alert(UNALLOWED_ID_MSG);
                userid.focus();
                userid.select();
                return 1;
	}

	return 0;
}

function ChangeUserProperty(service, idx) 
{
	var useridobj=document.getElementsByName(service+'_userid');
	var propertyobj=document.getElementsByName(service+'_property');
	var passobj=document.getElementsByName(service+'_passwd');
	var passtextobj=document.getElementsByName(service+'_passwd_text');
	var passviewobj=document.getElementsByName(service+'_password_view');
	
	if(propertyobj[idx].value == 'off')
	{		
		DisableObj(useridobj[idx]);
		DisableObj(passobj[idx]);
		DisableObj(passtextobj[idx]);
		DisableObj(passviewobj[idx]);
	}
	else
	{
		EnableObj(useridobj[idx]);
		EnableObj(passobj[idx]);
		EnableObj(passtextobj[idx]);
		EnableObj(passviewobj[idx]);
	}
}

function CheckIDList(user_id,my_idx,userobj,propertyobj)
{
	var i;

	for(i=0;i<propertyobj.length;i++)
	{
		if(my_idx == i) continue;

		if(userobj[i].value != '')
		{
			if(userobj[i].value == user_id)
				return 1;
		}
	}
	return 0;
}

function CheckDuplicateID(userobj,propertyobj)
{
	var i;

	for(i=0;i<propertyobj.length;i++)
	{
		if(userobj[i].value != '')
		{
			if(CheckIDList(userobj[i].value,i,userobj,propertyobj))
			{
				userobj[i].focus();
				userobj[i].select();
				return 1;
			}
		}
	}
	return 0;
}

function CheckUserForm(service)
{
	var i;
        var F2=nas_service_iframe.main_form;

	var useridobj=document.getElementsByName(service+'_userid');
	var passobj=document.getElementsByName(service+'_passwd');
	var passtextobj=document.getElementsByName(service+'_passwd_text');
	var passviewobj=document.getElementsByName(service+'_password_view');
	var propertyobj=document.getElementsByName(service+'_property'); /* only in FTP/Samba */
	
	for(i=0;i < useridobj.length;i++)
	{
		if(CheckUser(useridobj[i],passobj[i],passtextobj[i],passviewobj[i],propertyobj?propertyobj[i]:null))
			return 0;
		F2.user_id[i].value = useridobj[i].value;

		if(passviewobj[i].checked == true)
			F2.passwd[i].value = passtextobj[i].value;
		else
			F2.passwd[i].value = passobj[i].value;

		if(propertyobj[i]) F2.property[i].value = propertyobj[i].value;
		else F2.property[i].value = 'readwrite';
	}

	/* Check for At least one ID */
	if(propertyobj[0])
	{
		for(i=0;i<propertyobj.length;i++)
		{
			if(propertyobj[i].value != 'off')
				break;
		}
        
		if(i == propertyobj.length)
		{
			alert(MSG_ENABLE_ONE_SERVICE_ID);
			return 0;
		}
        
        
		if(CheckDuplicateID(useridobj,propertyobj))
		{
			alert(MSG_DUPLICATE_SERVICE_ID);
			return 0;
		}
	}

	return 1;
}

function ApplyNas()
{
        var F = document.nasmisc_fm;
        var F2=nas_service_iframe.main_form;
	var service = F.act.value;
	var i;

	F2.service.value = service;
	if(service == 'ipdisk')	
	{
		F2.run.value = GetRadioValue(F.ipdisk_run);
		if(F2.run.value == 0)
		{
			if(confirm(MSG_REMOVE_IPDISK_DDNS))
			{
				F2.hostname.value = F.hostname.value;
				F2.email.value = F.email.value;

				F.hostname.value = '';
				F.email.value = '';
				F2.submit();
				MaskIt(document,'apply_mask');
				return;
			}
			else
				return;
		}

                if((F.hostname.value.indexOf('_') != -1) || (F.hostname.value.indexOf('.') != -1))
                {
                        alert(EXPERTCONF_IPTIMEDDNS_INVALID_HOSTNAME);
                        F.hostname.focus();
                        F.hostname.select();
                        return;
                }
 
                if ((F.email.value.indexOf('@') == -1))
                {
                        alert(EXPERTCONF_IPTIMEDDNS_INVALID_USERID);
                        F.email.focus();
                        F.email.select();
                        return;
                }

		F2.hostname.value = F.hostname.value;
		F2.email.value = F.email.value;
		F2.submit();
		MaskIt(document,'apply_mask');
		return;
	}
	else if(service == 'ftp')
	{
		if (GetRadioValue(F.ftp_run) == 0)
		{
			F2.run.value="0";
        		F2.submit();
			MaskIt(document,'apply_mask');
			return;
		}


		if (F.ftp_port.value == '')
		{
                        alert(NATCONF_INTAPPS_FTP_PORT_EMPTY);
                        F.ftp_port.focus();
                        F.ftp_port.select();
                        return;
		}
        
		if (checkRange(F.ftp_port.value, 1, 65535) || (F.ftp_port.value == '80'))
		{
                        alert(NATCONF_INTAPPS_FTP_PORT_INVALID);
                        F.ftp_port.focus();
                        F.ftp_port.select();
                        return;
		}


                if (F.ipdisk_port)
                {
			if (F.ipdisk_port.value == '')
			{
                                alert(NATCONF_INTAPPS_FTP_PORT_EMPTY);
                        	F.ipdisk_port.focus();
                        	F.ipdisk_port.select();
                                return;
			} 

			if (checkRange(F.ipdisk_port.value, 1, 65535) || (F.ipdisk_port.value == '80'))
			{
                                alert(NATCONF_INTAPPS_FTP_PORT_INVALID);
                        	F.ipdisk_port.focus();
                        	F.ipdisk_port.select();
                                return;
			}
 	       }

		F2.run.value = GetRadioValue(F.ftp_run);
		F2.port_method.value = (F.ftp_port_method.checked == true)?"default":"";
		if(F.ipdisk_port_method) F2.ipdisk_port_method.value = (F.ipdisk_port_method.checked == true)?"default":"";
		F2.ftp_encoding.value = F.ftp_encoding.value;
		F2.ftp_port.value = F.ftp_port.value;
		if(F.ipdisk_port) F2.ipdisk_port.value = F.ipdisk_port.value;
	}
	else if(service == 'samba')
	{
		if (GetRadioValue(F.samba_run) == 0)
		{
			F2.run.value="0";
        		F2.submit();
			MaskIt(document,'apply_mask');
			return;
		}

		if (F.samba_name.value == '')
		{
                        alert(NASCONF_SAMBANAME_BLANK);
                        F.samba_name.focus();
                        F.samba_name.select();
                        return;
		}

		if (F.samba_group.value == '')
		{
                        alert(NASCONF_SAMBAGROUP_BLANK);
                        F.samba_group.focus();
                        F.samba_group.select();
                        return;
		}

		F2.run.value = GetRadioValue(F.samba_run);
		F2.samba_name.value = F.samba_name.value;
		F2.samba_group.value = F.samba_group.value;
	}
	else if(service == 'url')
	{
		if (GetRadioValue(F.url_run) == 0)
		{
			F2.run.value="0";
        		F2.submit();
			MaskIt(document,'apply_mask');
			return;
		}

		if (F.url_port.value == '')
		{
                        alert(NATCONF_INTAPPS_FTP_PORT_EMPTY);
                        F.url_port.focus();
                        F.url_port.select();
                        return;
		}
        
		if (checkRange(F.url_port.value, 1, 65535) || (parseInt(F.url_port.value) == 80))
		{
                        alert(NATCONF_INTAPPS_FTP_PORT_INVALID);
                        F.url_port.focus();
                        F.url_port.select();
                        return;
		}

		F2.run.value = GetRadioValue(F.url_run);
		F2.url_login.value = GetRadioValue(F.url_login);
		F2.url_port.value = F.url_port.value;
		F2.port_method.value = (F.url_port_method.checked == true)?"default":"";
	}
	else if(service == 'rsync')	
	{
		if (GetRadioValue(F.rsync_run) == 0)
		{
			F2.run.value="0";
        		F2.submit();
			MaskIt(document,'apply_mask');
			return;
		}

		if (F.rsync_port.value == '')
		{
                        alert(NATCONF_INTAPPS_FTP_PORT_EMPTY);
                        F.rsync_port.focus();
                        F.rsync_port.select();
                        return;
		}
        
		if (checkRange(F.rsync_port.value, 1, 65535) || (parseInt(F.rsync_port.value) == 80))
		{
                        alert(NATCONF_INTAPPS_FTP_PORT_INVALID);
                        F.rsync_port.focus();
                        F.rsync_port.select();
                        return;

		}

		if (F.new_folder.style.display != 'none' && (F.new_folder.value =='' || F.new_folder.value == F.default_folder.value))
		{
                        alert(MSG_NEW_FOLDER_ERR);
                        F.new_folder.focus();
                        //F.new_folder.select();
                        return;
		}

		if (GetValue(F.rsync_path) == 'select_backup_folder')
		{
		        alert(MSG_SELECT_FOLDER_ERR);
                        F.rsync_path.focus();
                        return;
		}

		if(GetValue(F.rsync_path).match('_create_DxLoE2LK'))
		{
			var arr = GetValue(F.rsync_path).split('_');
			var option_val, found;

			F.rsync_hddname.value = arr[0];
                        F.rsync_folder.value = F.new_folder.value;

			option_val = F.rsync_hddname.value+':'+F.rsync_folder.value;

			found = 0;
			for(i = 0 ; i < F.rsync_path.length; i++)
			{
				if(F.rsync_path[i].value == option_val)
				{
					F.rsync_path.value = option_val;
					found = 1;
					break;
				}
			}

			if(found == 0)
			{
				F.rsync_path[F.rsync_path.length] = new Option('/'+F.rsync_hddname.value+'/'+F.rsync_folder.value, option_val);
				F.rsync_path.value = F.rsync_hddname.value+':'+F.rsync_folder.value;
			}

			ChangeBackupFolder();
		}
		else
		{
			var arr = GetValue(F.rsync_path).split(':');

			F.rsync_hddname.value = arr[0];
			F.rsync_folder.value = arr[1];
		}

		F2.run.value = GetRadioValue(F.rsync_run);
		F2.rsync_port.value = F.rsync_port.value;
		F2.port_method.value = (F.rsync_port_method.checked == true)?"default":"";
		F2.rsync_hddname.value = F.rsync_hddname.value;
		F2.rsync_folder.value = F.rsync_folder.value;
	}


	if(!CheckUserForm(service))
		return;

        F2.submit();
	MaskIt(document,'apply_mask');
}



function RemoveUSB(value)
{
        var F = document.usbmgmt_fm;

        F.act.value="remove";
        F.devname.value=value;
        F.submit();
}

function MountUSB(value)
{
        var F = document.usbmgmt_fm;

        F.act.value="mount";
        F.devname.value=value;
        F.submit();
}



function InitURL()
{
        var F = document.nasmisc_fm;
	if(GetRadioValue(F.url_run) == 0)
	{
		if(F.url_port_method) DisableObj(F.url_port_method);
		DisableObj(F.url_port);
		DisableObj(F.url_login);
		DisableObj(F.url_userid);
		DisableObj(F.url_passwd);
		DisableObj(F.url_passwd_text);
		DisableObj(F.url_password_view);
	}
	else
	{
		if(F.url_port_method) EnableObj(F.url_port_method);
		EnableObj(F.url_port);
		EnableObj(F.url_login);
		EnableObj(F.url_login);

		if(GetRadioValue(F.url_login) == 1)
		{
			EnableObj(F.url_userid);
			EnableObj(F.url_passwd);
			EnableObj(F.url_passwd_text);
			EnableObj(F.url_password_view);
		}
		else
		{
			DisableObj(F.url_userid);
			DisableObj(F.url_passwd);
			DisableObj(F.url_passwd_text);
			DisableObj(F.url_password_view);
		}
	}
	ClickURLPortMethod();
}

function InitSamba()
{
        var F = document.nasmisc_fm;

	if(GetRadioValue(F.samba_run) == 0)
	{
		DisableObj(F.samba_name);
		DisableObj(F.samba_group);

		DisableObjNames('samba_property');
		DisableObjNames('samba_userid');
		DisableObjNames('samba_passwd');
		DisableObjNames('samba_passwd_text');
		DisableObjNames('samba_password_view');
	}
	else
	{
		EnableObj(F.samba_name);
		EnableObj(F.samba_group);

		EnableObjNames('samba_property');
		EnableObjNames('samba_userid');
		EnableObjNames('samba_passwd');
		EnableObjNames('samba_passwd_text');
		EnableObjNames('samba_password_view');

		for(i=0;i<F.samba_userid.length;i++)
			ChangeUserProperty('samba',i);
	}
}


function InitFTP()
{
        var F = document.nasmisc_fm;
	var i;

	if(GetRadioValue(F.ftp_run) == 0)
	{
		if(F.ftp_port_method) DisableObj(F.ftp_port_method);
		DisableObj(F.ftp_port);
		DisableObj(F.ftp_encoding);

		DisableObjNames('ftp_property');
		DisableObjNames('ftp_userid');
		DisableObjNames('ftp_passwd');
		DisableObjNames('ftp_passwd_text');
		DisableObjNames('ftp_password_view');

		if(F.ipdisk_port_method) 
		{
			DisableObj(F.ipdisk_port_method);
			DisableObj(F.ipdisk_port);
		}
	}
	else
	{
		if(F.ftp_port_method) EnableObj(F.ftp_port_method);

		EnableObj(F.ftp_port);
		EnableObj(F.ftp_encoding);

		EnableObjNames('ftp_property');
		EnableObjNames('ftp_userid');
		EnableObjNames('ftp_passwd');
		EnableObjNames('ftp_passwd_text');
		EnableObjNames('ftp_password_view');

		if(F.ipdisk_port_method) 
		{
			EnableObj(F.ipdisk_port_method);
			EnableObj(F.ipdisk_port);
		}

		for(i=0;i<F.ftp_userid.length;i++)
			ChangeUserProperty('ftp',i);
	}

	ClickServicePortMethod();
	ClickFTPPortMethod();

}


function InitipDISK()
{
        var F = document.nasmisc_fm;

	if(GetRadioValue(F.ipdisk_run) == 0)
	{
		DisableObj(F.hostname);
		DisableObj(F.email);
	}
	else
	{
		EnableObj(F.hostname);
		EnableObj(F.email);
	}
}




function ClickRsyncPortMethod()
{
        var F = document.nasmisc_fm;

	if(!F.rsync_port_method)
		return;
        if (F.rsync_port_method.checked == false)
	{
		ReadOnlyObj(F.rsync_port,0);
	}
	else
	{
		F.rsync_port.value=1873;
		ReadOnlyObj(F.rsync_port,1);
	}

}


function InitRsync()
{
        var F = document.nasmisc_fm;
	if(GetRadioValue(F.rsync_run) == 0)
	{
		if(F.rsync_port_method) DisableObj(F.rsync_port_method);
		DisableObj(F.rsync_port);
		DisableObj(F.rsync_userid);
		DisableObj(F.rsync_passwd);
		DisableObj(F.rsync_passwd_text);
		DisableObj(F.rsync_password_view);
		DisableObj(F.rsync_path);
		DisableObj(F.new_folder);
	}
	else
	{
		if(F.rsync_port_method) EnableObj(F.rsync_port_method);
		EnableObj(F.rsync_port);
		EnableObj(F.rsync_userid);
		EnableObj(F.rsync_passwd);
		EnableObj(F.rsync_passwd_text);
		EnableObj(F.rsync_password_view);
		EnableObj(F.rsync_path);
		EnableObj(F.new_folder);
	}
	ClickRsyncPortMethod();
}


function ChangeBackupFolder()
{
        var F = document.nasmisc_fm;

	if(GetValue(F.rsync_path).match('_create_DxLoE2LK'))
	{
		ShowObj(F.new_folder);

           	F.new_folder.value = F.default_folder.value;
                F.new_folder.style.color = "#aaaaaa";
	}
	else
		HideObj(F.new_folder);

	

}

function  FocusNewFolder()
{
        var F = document.nasmisc_fm;

        if(F.new_folder.value == F.default_folder.value)
        {
                F.new_folder.value = '';
                F.new_folder.style.color = "#000000";
        }
}


</script>
