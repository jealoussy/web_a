<script>
//sysconf_syslog

function ApplySyslog()
{
	var F=document.syslog_fm;
	F.act.value = 'apply';
	F.submit();
}

function ToggleEmailLog()
{
	var F=document.syslog_fm;;
	if(F.log_email_chk.checked == false )
	{
		F.email_hour.disabled = true;
		F.log_rmflag_chk.disabled = true;
	}
	else if(F.log_email_chk.checked == true )
	{
		F.email_hour.disabled = false;
		F.log_rmflag_chk.disabled = false;
	}
}

function Apply_Email()
{
	var F=document.syslog_fm;
	if((F.log_email_chk.checked == true) && checkRange(F.email_hour.value, 0, 23)) 
		alert(SYSCONF_SYSLOG_WANRING );
	else 
	{
		F.act.value = "apply";
		F.submit(); 
	}
}

function Send_Email()
{
	var F=document.syslog_fm;
	if(confirm(SYSCONF_SYSLOG_EMAIL_CONFIRM ))
	{
		F.act.value = "sendmail";
		F.submit(); 
	}
}

function RemoveLog()
{
	var F=document.syslog_fm;
	if(confirm(SYSCONF_SYSLOG_CLEAR_CONFIRM )) 
	{
		F.act.value = "remove";
		F.submit(); 
	}
}

//sysconf_login
function check_login_id(s)
{
        for( i = 0 ; i < s.length; i++ )
        {
                if(((s.charAt(i) >= 'a') && (s.charAt(i) <= 'z')) ||
                        ((s.charAt(i) >= 'A' ) && (s.charAt(i) <= 'Z')) ||
                        ((s.charAt(i) >= '0' ) && (s.charAt(i) <= '9')) )
                                continue;
        else
                        return false;
       }
       return true;
}

function ApplyLogin()
{
        var F = document.login_fm;

        if (F.new_passwd.value != F.confirm_passwd.value)
                alert(SYSCONF_LOGIN_INVALID_NEW_PASS);
        else if(F.new_login && check_login_id(F.new_login.value) == false)
                alert(SYSCONF_LOGIN_INVALID_NEW_ID);
        else
        {

		var F2=document.session_fm;

		if(F2 && (GetValue(F2.prev_auth_method) == 'session'))
		{

			if(F.new_login)
			{	
                		if (F.new_login.value == '' || F.new_passwd.value == '')   
				{
                			alert(SYSCONF_LOGIN_CANT_REMOVE_ID);
					F.new_passwd.focus();
					return 0;
				}
			}
		}


                if (F.new_login && F.new_login.value == '' && F.new_passwd.value == '')   
		{
                	if (confirm(SYSCONF_LOGIN_REMOVE_WARNING))
			{
                        	F.act.value = 'save';
                        	F.submit();
				return 0;
			}
			else
				return 0;
		}


                if (confirm(SYSCONF_LOGIN_RELOGIN))
                {
                        F.act.value = 'save';
                        F.submit();
                }
        }
}

function ApplySession()
{
        var F = document.session_fm;

	if(!F.http_auth)
		return;

	if(GetValue(F.http_auth) == 'session' && F.noid.value == '1')
	{
        	alert(SYSCONF_LOGIN_SHOULD_HAVE_IDPASS);
		return 0;
	}

	if(GetValue(F.http_auth) == 'session')
	{
		session_timeout=parseInt(F.http_session_timeout.value);
		if((session_timeout <=0) || (session_timeout >= 61))
		{
			alert(SYSCONF_LOGIN_INVALID_SESSION_TIMEOUT);
			F.http_session_timeout.focus();
			return 0;
		}
	}

        if (confirm(SYSCONF_LOGIN_RELOGIN_SESSION))
        {
                F.act.value = 'session_save';
                F.submit();
        }
}

function InitLogin()
{
        var F = document.session_fm;

	if(F.http_auth) 
	{
		if(GetValue(F.http_auth) == 'basic')
		{
			F.http_session_timeout.disabled = true;
			F.use_captcha.disabled = true;
		}
		else
		{
			F.http_session_timeout.disabled = false;
			F.use_captcha.disabled = false;
		}
		return 0;
	}
}

function ChangeEmailConfig()
{
        var F = document.email_fm;
        F.act.value = 'apply_email';
        F.submit();
}

function ChangeAuth()
{
        var F = document.email_fm;
        if(F.smtp_auth[0].checked == true)
        {
                EnableObj(F.account);
                EnableObj(F.smtp_pass);
        }
        else
        {
                DisableObj(F.account);
                DisableObj(F.smtp_pass);
        }
}

//sysconf_realtime
function SelectTimeServer()
{
      var F = document.realtime_fm;
      if(F.server_list.value == 'null')
              EnableObj(F.server_edit);
      else
              DisableObj(F.server_edit);
}
function ApplyTimeServer()
{
      var F=document.realtime_fm;
      F.act.value='apply';
      F.submit();
}

// sysconf_configmgmt 
function RestoreConfig()
{
	var F = document.restore_fm; 
	if(F.restore_config_file.value.length == 0 )
       	{
		alert(MSG_RESTOREFILE_BLANK);
                return;
       	}
	ApplyReboot(document.restore_fm,'restore');
}

// sysconf_misc
function ApplyMisc(value)
{
        var F = document.misc_fm;

	if(value == 'wbm_popup')
		alert(MSG_WBM_POPUP);

        F.act.value=value;
        F.submit();
}

function OnClickSilentLED()
{
	var F = document.misc_fm;

	if(GetValue(F.led_flag) == 2)
	{
		EnableObj(F.led_start);
		EnableObj(F.led_end);
	}
	else
	{
		DisableObj(F.led_start);
		DisableObj(F.led_end);
	}
}


</script>
