<script>

//login_navi
function login_session()
{
	// Check ID Password 

	// Check captcha if exist
	//location.href = "../testbin/login.cgi";
	//
	document.form.submit();
}

</script>
